/*
 * ekf_coder_initialize.h
 *
 * Code generation for function 'ekf_coder_initialize'
 *
 * C source code generated on: Mon Jun  9 07:29:50 2014
 *
 */

#ifndef __EKF_CODER_INITIALIZE_H__
#define __EKF_CODER_INITIALIZE_H__
/* Include files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_defines.h"
#include "rt_nonfinite.h"

#include "rtwtypes.h"
#include "ekf_coder_types.h"

/* Function Declarations */
extern void ekf_coder_initialize();
#endif
/* End of code generation (ekf_coder_initialize.h) */
