/*
 * rtGetInf.h
 *
 * Code generation for function 'correctStateAndCov'
 *
 * C source code generated on: Sun Aug 17 12:20:38 2014
 *
 */

#ifndef __RTGETINF_H__
#define __RTGETINF_H__

#include <stddef.h>
#include "rtwtypes.h"
#include "rt_nonfinite.h"

extern real_T rtGetInf(void);
extern real32_T rtGetInfF(void);
extern real_T rtGetMinusInf(void);
extern real32_T rtGetMinusInfF(void);

#endif
/* End of code generation (rtGetInf.h) */
