/*
 * mpower.h
 *
 * Code generation for function 'mpower'
 *
 * C source code generated on: Sun Aug 17 12:20:38 2014
 *
 */

#ifndef __MPOWER_H__
#define __MPOWER_H__
/* Include files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_defines.h"
#include "rt_nonfinite.h"

#include "rtwtypes.h"
#include "ekf_coder_types.h"

/* Function Declarations */
extern void mpower(const emxArray_real_T *a, emxArray_real_T *c);
#endif
/* End of code generation (mpower.h) */
